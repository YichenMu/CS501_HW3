package com.example.w3_p3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView f_ans;
    private TextView f_txt;
    private TextView c_ans;
    private TextView c_txt;
    private SeekBar c_seekBar;
    private SeekBar f_seekBar;
    private TextView interesting_msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        f_ans = (TextView) findViewById(R.id.f_ans);
        f_txt = (TextView) findViewById(R.id.f_txt);
        c_ans = (TextView) findViewById(R.id.c_ans);
        c_txt = (TextView) findViewById(R.id.c_txt);
        c_seekBar = (SeekBar) findViewById(R.id.c_seekBar);
        f_seekBar = (SeekBar) findViewById(R.id.f_seekBar);
        interesting_msg = (TextView) findViewById(R.id.interesting_msg);
        Locale spanish = new Locale("es", "ES");

        c_seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                c_ans.setText("" + i + "");
                Double convert = new Double( i * 1.8 + 32);

                if(convert > 31) {
                    int i_convert = convert.intValue();
                    f_seekBar.setProgress(i_convert);
                    f_ans.setText("" + convert + "");
                }
                else {
                    c_seekBar.setProgress(0);
                    f_seekBar.setProgress(32);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int celsius = seekBar.getProgress();
                if(celsius <= 20 && Locale.getDefault().equals(Locale.ENGLISH))
                    interesting_msg.setText("I wish it were warmer.");
                else if(celsius <= 20 && Locale.getDefault().equals(spanish))
                    interesting_msg.setText("Ojalá fuera más cálido.");
                else if(celsius > 20 && Locale.getDefault().equals(spanish))
                    interesting_msg.setText("Ojala fuera mas frio.");
                else if(celsius > 20 && Locale.getDefault().equals(Locale.ENGLISH))
                    interesting_msg.setText("I wish it were colder.");
            }
        });

        f_seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                f_ans.setText("" + i + "");
                Double convert = new Double((i - 32) * .5556);

                if(convert > 0) {
                    int i_convert = convert.intValue();
                    c_seekBar.setProgress(i_convert);
                    c_ans.setText("" + convert + "");
                }
                else {
                    c_seekBar.setProgress(0);
                    f_seekBar.setProgress(32);
                }

                if(convert <= 20){
                    interesting_msg.setText("I wish it were warmer.");
                }
                else
                    interesting_msg.setText("I wish it were colder.");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int fahren = seekBar.getProgress();
                Double celsius = new Double((fahren- 32) * .5556);
                if(celsius <= 20 && Locale.getDefault().equals(Locale.ENGLISH))
                    interesting_msg.setText("I wish it were warmer.");
                else if(celsius <= 20 && Locale.getDefault().equals(spanish))
                    interesting_msg.setText("Ojalá fuera más cálido.");
                else if(celsius > 20 && Locale.getDefault().equals(spanish))
                    interesting_msg.setText("Ojala fuera mas frio.");
                else if(celsius > 20 && Locale.getDefault().equals(Locale.ENGLISH))
                    interesting_msg.setText("I wish it were colder.");
            }
        });
    }
}