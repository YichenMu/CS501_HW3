package com.example.flashcard.flashcard;

public class NumberConstant {
    public static final int hardBound = 100;
    public static final int mediumBound = 21;
    public static final int totalQuestion = 10;
}
