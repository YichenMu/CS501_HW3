A valid account username: guest  password: 123456  
You can also click "sign in as guest" button to sign in derectly