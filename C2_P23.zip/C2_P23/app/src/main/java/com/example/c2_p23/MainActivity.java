package com.example.c2_p23;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView txtvlight;
    private Button btnchange;
    private int[] array;
    private int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtvlight = (TextView) findViewById(R.id.txtvlight);
        btnchange = (Button) findViewById(R.id.btnchange);
        txtvlight.setText(getResources().getString(R.string.initiate));
        array = new int[]{getResources().getColor(R.color.red), getResources().getColor(R.color.yellow), getResources().getColor(R.color.green)};
        btnchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Delete the text on the view
                txtvlight.setText("");
                while(count < 3){
                    // Set the color of textview in while loop
                    txtvlight.setBackgroundColor(array[count]);
                    count++;
                    if (count == 3)
                        count = 0;
                    break;
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}