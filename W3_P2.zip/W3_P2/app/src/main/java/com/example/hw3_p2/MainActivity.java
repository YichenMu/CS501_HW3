package com.example.hw3_p2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private final String LOGTAG = "States";
    private Button btnhello;
    private EditText edt1;
    private TextView txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(LOGTAG, "onCreate");
        btnhello = (Button) findViewById(R.id.btnhello);
        edt1 = (EditText) findViewById(R.id.edt1);
        txt1 = (TextView) findViewById(R.id.txt1);

        btnhello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1 = "Hello";
                edt1.setText(s1.toString());
                txt1.setText(s1.toString());
            }
        });
    }

    @Override
    protected void onStart() {
        Log.i(LOGTAG, "onStart");
        super.onStart();
    }

    @Override
    protected void onRestart() {
        Log.i(LOGTAG, "onRestart");
        super.onRestart();
    }

    @Override
    protected void onResume() {
        Log.i(LOGTAG, "onResume");
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.i(LOGTAG, "onPause");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.i(LOGTAG, "onStop");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.i(LOGTAG, "onDestroy");
        super.onDestroy();
    }
}